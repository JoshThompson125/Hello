
/**
 * This program will print out a greeting.
 * @author Josh Thompson
 * @version 1.0
 */
public class Hello
{
 public Hello()
 {
       
 }
 public static void main(String[] args)
 {
  System.out.println("Hello World!");
 }
}